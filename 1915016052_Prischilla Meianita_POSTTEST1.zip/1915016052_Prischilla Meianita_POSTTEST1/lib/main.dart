import 'package:flutter/material.dart';

void main() => runApp(MyApp());

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Welcome to Flutter',
      home: MainPage(),
    );
  }
}

class MainPage extends StatelessWidget {
  const MainPage({ Key? key }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    var mediaQueryWidth = MediaQuery.of(context).size.width;
    var mediaQueryHeight = MediaQuery.of(context).size.height;
    return Scaffold(
        appBar: AppBar(
          title: Center(child: Text('Posttest 1 Prischilla')),
        ),
        
        body: Center(
          child: Container(
            width: mediaQueryWidth / 2,
            height: mediaQueryHeight / 2,
            decoration: BoxDecoration(
              color: Color.fromARGB(255, 241, 179, 194),
              border: Border.all(
                color: Color.fromARGB(255, 235, 140, 187),
                width: 5,
              ),
            borderRadius: BorderRadius.circular(20),
            ),

            child: Center(child: Text('Semoga Posttest 2 tidak susah trims',
              style: TextStyle(
                color: Colors.white,
                fontSize: 20),)))),
    );
  }
}